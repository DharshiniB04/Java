class clg
{
    void name()
    {
        System.out.println("MKCE");
    }
}
class Place extends clg
{
    void city()
    {
        System.out.println("Karur");
    }
    void loc()
    {
        System.out.println("Thalavapalayam");
    }
}

public class Main extends Place
{
	public static void main(String[] args) {
	    Main m=new Main();
	    System.out.println("My College...");
	    m.name();
	    m.city();
	    m.loc();
	}
}
