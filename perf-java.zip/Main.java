/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int a = s.nextInt();
		int b = 1;
		while(b!=a){
		int c = 0;
		for(int i = 1; i<a; i++){
		    if(a%i==0){
		        c+=i;
		    }
		}
		if(c==b){
		System.out.println(c);
		}
		}
		b++;
	}
}
