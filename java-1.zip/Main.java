import java.util.*;
public class Main
{
	public static void main(String[] args) {
		Scanner s = new Scanner (System.in);
		System.out.println("Enter the salary of Virat in RCB: ");
		float t1pl1 = s.nextFloat();
		System.out.println("Enter the salary of Maxwell in RCB: ");
		float t1pl2 = s.nextFloat();
		System.out.println("Enter the salary of Siraj 3 in RCB: ");
		float t1pl3 = s.nextFloat();
		System.out.println("Enter the salary of Dhoni in CSK: ");
		float t2pl1 = s.nextFloat();
		System.out.println("Enter the salary of Rutraj in CSK: ");
		float t2pl2 = s.nextFloat();
		System.out.println("Enter the salary of Jadeja in CSK: ");
		float t2pl3 = s.nextFloat();
		float t1 = t1pl1+t1pl2+t1pl3;
		System.out.println("The total Salary of RCB : "+t1);
		float t2 = t2pl1+t2pl2+t2pl3;
		System.out.println("The total Salary of CSK : "+t2);
		float t = (t1+t2)/2;
		System.out.println("The average Salary of both teams : "+t);
	}
}
