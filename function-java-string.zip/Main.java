

public class Main
{
	public static void main(String[] args) {
	/* CHARAT()	
	String name="TERV TEAM";
		 char ch=name.charAt(3);
		System.out.print(ch);
	*/
	/* STRING Compare 
	equals()
	String s1="Sachin";
	String s2=new String("Sachin");
	System.out.print(s1.equals(s2));
	*/
	/*
	==
	String s1="Sachin";
	String s2=new String("Sachin");
	String s3="Sachin";
	System.out.print(s1==s2);
	System.out.print(s1==s3);
	*/
	/*
	compareTo()
	String s1="hello";
	String s2="hello";
	String s3="meklo";
	String s4="hemlo";
	System.out.print(s1.compareTo(s2));
	System.out.print(s1.compareTo(s3));
	System.out.print(s1.compareTo(s4));
	*/
	/*
	String concat
	String s1= "java String";
	s1.concat("is immutable");
	System.out.print(s1);
	s1=s1.concat(" is immutable so assign it explicitly");
	System.out.print(s1);
	*/
	/*
	String Contains
	String s1= "What do you do?";
	String s2= "do";
	System.out.print(s1.contains(s2));
	*/
	/*
	double a=123.678;
	    String b=String.valueOf(a);
		System.out.println(b.indexOf('2'));
		b=b.replace('3','7');
		System.out.println(b);
		b=b.replaceFirst("7","9");
		System.out.println(b);
		String k="Team Terv";
		String j[]=k.split(" ",2);
		for(String i:j)
		System.out.println(i);
		String m[]=k.split("e");
			for(String i:m)
		System.out.println(i);
		k="hii terv team";
	   System.out.println(k.subSequence(4,8));
	   char v[]=k.toCharArray();
	   String x="";
	   x=x.copyValueOf(v,0,5);
	   System.out.println(x);
	   */
	}
}
