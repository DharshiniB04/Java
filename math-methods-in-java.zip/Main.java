import java.util.*;
public class Main
{
	public static void main(String[] args) {
	    Scanner s = new Scanner(System.in);
	    int a = s.nextInt();
	    int b = s.nextInt();
	    int c = s.nextInt();
	    int d = s.nextInt();
	    float e = s.nextFloat();
	    System.out.println("OUTPUT:");
	    System.out.println(Math.pow(a,b));
	    System.out.println(Math.sqrt(c));
	    System.out.println(Math.max(a,c));
	    System.out.println(Math.min(a,b));
	    System.out.println(Math.abs(d));
	    System.out.println(Math.floor(e));
	    System.out.println(Math.ceil(e));
	    System.out.println(Math.round(e));
	    
	}
}
